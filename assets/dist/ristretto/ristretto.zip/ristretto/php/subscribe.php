<?php
/*
Ristretto
Handcrafted by Haundo Design
*/

$api_key = "api_key";
$list_id = "list_id";

require('Mailchimp.php');
$Mailchimp = new Mailchimp( $api_key );
$Mailchimp_Lists = new Mailchimp_Lists( $Mailchimp );

try {
  $subscriber = $Mailchimp_Lists->subscribe( $list_id, array( 'email' => $_POST['subscribe'] ) );
  $response = 'Thank you for subscribing to our newsletter. You will receive an email to confirm the subscription.';
} catch (Exception $error) {
  http_response_code(500);
  $response = $error->getMessage();
}

echo $response;
?>