<?php
/*
Ristretto
Handcrafted by Haundo Design
*/

$name = strip_tags($_POST["name"]);
$from = strip_tags($_POST["email"]);
$body = strip_tags($_POST["message"]);
$to = 'example@example.com'; // Email the form is sent from.
$subject = '[Ristretto]';

if( $name && $from && $body ) {
  $sent = mail( $to, $subject, $body, $from );

  if( $sent ) {
    http_response_code(200);
    echo 'Thank you ' . $name . ', your message has been succesfully sent.';
  } else {
    http_response_code(500);
    echo 'There was an error trying to send the message: ' . $mail->ErrorInfo . ' Please try again.';
  }
} else {
  http_response_code(400);
  echo 'Please, fill empty fields before submitting the form.';
}

die();
?>