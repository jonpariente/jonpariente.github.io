# Ristretto

Ristretto is a minimalist, full-screen designed coming soon template.

## Getting started

An overview of Ristretto, folder structure, included files, how to use and setting up.

### What's included

Every downloaded copy of Ristretto is compressed. Once downloaded, unzip the compressed folder to get a structure like this:

```
ristretto/
├── css/
│   └── ristretto.css
├── fonts/
├── img/
├── js/
│   └──  ristretto.js
├── php/
│   ├── Mailchimp/
│   ├── contact.php
│   ├── Mailchimp.php
│   └── subscribe.php
├── sass/
├── config.rb
├── index.html
└── README.md
```

- **ristretto.js** for configuration and functionality.
- **ristretto.css** for style.
- **contact.php** for contact form.
- **subscribe.php** for subscription form.
- **config.rb** for sass project configuration.

### Installation
#### Download

Copy folder structure in to your project to start using Ristretto.


## Customization
### Date

`Type: JavaScript Date Object`

Open **ristretto.js** to edit the date of the countdown end.

```javascript
var settings = {
  // Replace date
  date: '05/10/2017 09:00:00',
  ...
};
```

### Background

`Type: Boolean, String` `Default: false` `Value: false, 'image', 'slides', 'video'`

Open **ristretto.js** to edit the background style of the template. False and 'image' set a static image as background, slides sets a group of 4 rotating images as background and video sets a dynamic background playing a video.

```javascript
var settings = {
  ...
  // Change background to slides
  background: 'slides',  
  ...
};
```

Open **ìmg/** to edit images displayed in the background. Replace existing images, named background_x.jpg, with your own keeping same file names and file extensions. To edit images without overwritting existing ones, open **ristretto.css** and edit the path in the `background-image` property.

```css
.image {
  background-image: url('path/to/background1.jpg');
}

.slide-1 {
  background-image: url('path/to/background2.jpg');
}

.slide-2 {
  background-image: url('path/to/background3.jpg');
}

.slide-3 {
  background-image: url('path/to/background4.jpg');
}

.slide-4 {
  background-image: url('path/to/background5.jpg');
}
```

To edit background video, open **index.html** and replace `src` of `source` with the video file name. Save videos in **video/**.

```html
<video class="video hidden" autoplay loop muted>
  <source src="video/FILE_NAME.webm" type="video/webm">
  <source src="video/FILE_NAME.mp4" type="video/mp4">
</video>
```

### Title

`Type: Boolean` `Default: true` `Values: true, false`

Open **ristretto.js** to display a title or not in the main page, above the countdown.

```javascript
var settings = {
  ...
  // Hide title
  showTitle: false,  
  ...
};
```

### Countdown tags

`Type: Boolean` `Default: true` `Values: true, false`

Open **ristretto.js** to display a descriptive text tag below each counter.

```javascript
var settings = {
  ...
  // Hide tags
  showCountdownTags: false    
};
```

### Text

Open **index.html** to edit template text. You can add your own social networks to the template, edit `href` attribute with an URL to your profile.

```html
<ul class="list-inline social-networks">
  <li><a href="#"><span class="fa fa-twitter"><span class="hidden">Twitter</span></span></a></li>
  <li><a href="#"><span class="fa fa-facebook"><span class="hidden">Facebook</span></span></a></li>
  <li><a href="#"><span class="fa fa-dribbble"><span class="hidden">Dribbble</span></span></a></li>
  <li><a href="#"><span class="fa fa-behance"><span class="hidden">Behance</span></span></a></li>
  <li><a href="#"><span class="fa fa-google-plus"><span class="hidden">Google+</span></span></a></li>
</ul>
```

### Icons

Ristretto uses [FontAwesome](http://fontawesome.io/) icons. You can replace this icons for your owns.

```html
<!-- FontAwesome -->
<span class="fa fa-icon"></span>
```

Open **index.html** to replace the favicon. A favicon, also known as a shortcut icon, is a file containing an icon related to a webpage.

```html
<link rel="shortcut icon" href="path/to/favicon.png">
```

### Forms

To change the email account where contact forms are sent, open **contact.php** and replace the email for your own.
To receive emails throught PHP, server must be PHP 5.3+ compatible. 

```php
// Replace account
$to = 'example@example.com';
```

To get subscriptions, a Mailchimp account is needed. MailChimp is an email marketing service used to create, send, and track email newsletters. Once an account is created, get the API key and a list ID form your account, open **subscribe.php** and replace the information for both fields. For more information about how to get an API key, create a list and get the ID, visit [Mailchimp](http://mailchimp.com).

```php
// Replace values for both variables
$api_key = "api_key";
$list_id = "list_id";
```

### Sass

Ristretto is built with Sass. To create a customized version, open `_variables.scss` file and edit variables, then compile `ristretto.scss` to generate a custom stylesheet.