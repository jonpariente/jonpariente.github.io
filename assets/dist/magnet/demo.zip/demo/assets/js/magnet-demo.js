$(document).ready(function() {
	$('.element').each(function(elem) {
		var random = Math.floor((Math.random() * 10) + 1);
		if ( random === 8 ) {
			$(this).addClass('--width2');
		} else if ( random === 9 ) {
			$(this).addClass('--height2');
		} else if ( random === 10 ) {
			$(this).addClass('--width2 --height2');
		}
	});

	var $magnet = $('.periodic-table').magnet({
		itemSelector: '.element'
	});	
	
	$('.filter-group').on('click', 'button', function() {
		var filter = $(this).data('filter');
		$magnet.magnet({ filter: filter });
		
		$(this).siblings().removeClass('active');
		$(this).addClass('active');
	});

	$('.btn-destroy').click(function() {
		$magnet.magnet('destroy');
		$('.filter-group').off('click');
	});
});

