/**
 * Magnet - v.2.0.0
 *
 * Copyright 2016 by Haundo Design
 */

( function( window, factory ) {
  if ( typeof define === 'function' && define.amd ) {
    define( factory( window ) );
  } else if ( typeof exports === 'object' ) {
    module.exports = factory( window );
  } else {
    window.Magnet = factory( window );
  }
}( this, function( window ) {
  'use strict';

  // -------------------- Functions --------------------

  /**
   * Get element size
   *  
   * @param {Element} elem
   * @return {Object} size - width & height
   */
  function getSize( elem ) {
    // Use querySelector if element is string
    if ( typeof elem == 'string' ) {
      elem = document.querySelector( elem );
    }

    // Do not proceed on non-objects
    if ( !elem || typeof elem != 'object' || !elem.nodeType ) {
      return;
    }

    // Size includes padding and border if
    // box sizing is set to border-box.
    var size = {
      width: elem.offsetWidth,
      height: elem.offsetHeight
    };
    
    var style = getComputedStyle( elem );
    // Get element measurements
    var measurements = {
      width: 0,
      height: 0,
      marginLeft: 0,
      marginRight: 0,
      marginTop: 0,
      marginBottom: 0,
      paddingLeft: 0,
      paddingRight: 0,
      paddingTop: 0,
      paddingBottom: 0,
      borderLeft: 0,
      borderRight: 0,
      borderTop: 0,
      borderBottom: 0
    };

    for ( var measurement in measurements ) {
      var value = style[ measurement ];
      var num = parseFloat( value );
      measurements[ measurement ] = isNaN( num ) ? 0 : num;
    };

    var marginX = measurements.marginLeft + measurements.marginRight;
    var marginY = measurements.marginTop + measurements.marginBottom;
    var paddingX = measurements.paddingLeft + measurements.paddingRight;
    var paddingY = measurements.paddingTop + measurements.paddingBottom;
    var borderX = measurements.borderLeft + measurements.borderRight;
    var borderY = measurements.borderTop + measurements.borderBottom;
    
    var borderBox = size.borderBox = style.boxSizing === 'border-box';
    
    // Overwrite width and height if style returns a number.
    // Add padding and border if not already included
    if ( measurements.width ) {
      size.width = measurements.width +
        ( borderBox ? 0 : paddingX + borderX );
    }

    if ( measurements.height ) {
      size.height = measurements.height +
        ( borderBox ? 0 : paddingY + borderY );
    }

    size.innerWidth = size.width - ( paddingX - borderX );
    size.innerHeight = size.height - ( paddingY - borderY );
    size.outerWidth = size.width + marginX;
    size.outerHeight = size.height + marginY;

    return size;
  }

  /**
   * Get element position
   *  
   * @param {Element} elem
   * @return {Object} position - x & y
   */
  function getPosition( elem ) {
    var position = {
      x: parseInt( getComputedStyle( elem ).left, 10 ),
      y: parseInt( getComputedStyle( elem ).top, 10 )
    };

    // Clean up 'auto' an other non-integer values
    for ( var coord in position ) {
      var value = position[ coord ];
      position[ coord ] = isNaN( value ) ? 0 : value;
    }

    return position;
  }

  /**
   * Get a function to sort items
   *
   * @param {Array} sortBys - sort keys
   * @param {Boolean or Object} sortAsc - sort direction
   * @return {Function}
   */
  function getItemSorter( sortBys, sortAsc ) {
    return function sorter( itemA, itemB ) {
      // Goes through all sort keys
      for ( var i = 0; i < sortBys.length; i++ ) {
        var sortBy = sortBys[i];
        
        // Get item sort data for given key
        function getSortData( item ) {
          return item.sortData[ sortBy ];
        }

        var a = getSortData( itemA );
        var b = getSortData( itemB );
        // Compare sort datas if not equals
        if ( a > b || a < b ) {
          // If sortAsc is an object, use the value given in the key
          var ascending = sortAsc[ sortBy ] !== undefined ? sortAsc[ sortBy ] : sortAsc;
          var direction = ascending ? 1 : -1;
          return sorters.alphanumeric( a, b ) * direction;
        }
      }
      return 0;
    };
  }

  /**
   * Get whether an element matches a selector or not
   * 
   * @param {Element} elem
   * @param {String} selector
   * @return {Boolean}
   */
  function matchesSelector( elem, selector ) {
    var matchesSelector = elem.matches ||
                          elem.matchesSelector ||
                          elem.msMatchesSelector ||
                          elem.mozMatchesSelector ||
                          elem.webkitMatchesSelector ||
                          elem.oMatchesSelector;

    return matchesSelector.call( elem, selector );
  }

  /**
   * Transform data given by a sorter to get a function
   * that obtains the appropiate value.
   * `.class` use the text of `.class` as a querySelector.
   * `data-class` use attribute.
   * `.class parseInt` parse value as a number.
   * `.class parseFloat` parse value as a floating point number
   *
   * @param {NodeList} elems
   * @param {String or Function} sorter
   * @return {Function} sorter
   */
  function mungeSorter( elems, sorter ) {
    // If not a string, return whatever it was used
    if ( typeof sorter != 'string' ) {
      return sorter;
    }

    // Parse sorter string
    var args = sorter.trim().split(' ');
    // Use the first argument as a sorter
    var query = args[0];
    // Check if query looks like an [attribute]
    var attr = query.match( /\[([^\]]+)]/ );
    attr = attr && attr[1]; 

    function getValueGetter( attr, query ) {
      // if query is attribute, get attribute
      if ( attr ) {
        return function getAttribute( elem ) {
          return elem.getAttribute( attr );
        };
      }
      // Otherwise, assume it's a querySelector and get its text
      return function getText( elem ) {
        var child = elem.querySelector( query );
        return child.textContent;
      };
    }

    var getParsedValue;
    var getValue;
    var getVal = getValueGetter( attr, query );
    // Use the second argument as a parser.
    // Get the parser from the global parsers object
    var parser = parsers[ args[1] ];

    sorter = parser ?
    // Parse the value, if it was a parser
    getParsedValue = function( elem ) {
      return parser( getVal( elem ) );
    } :
    // Otherwise, return the value
    getValue = function( elem ) {
      return getVal( elem );
    }

    return sorter;
  }

  // -------------------- Utils --------------------

  var utils = {
    // Merge the content of two objects into the first object
    extend: function( a, b ) {
      for ( var prop in b ) {
        a[ prop ] = b[ prop ];
      }
      return a;
    },
    // Convert an array-like object into a true JavaScript array
    toArray: function( obj ) {
      var arr = [];

      if ( Array.isArray( obj ) ) {
        arr = obj;
      } else if ( obj instanceof jQuery || obj instanceof HTMLCollection || obj instanceof NodeList ) {
        arr = [].slice.call( obj );
      } else {
        arr.push( obj );
      }

      return arr;
    },
    // Check if object is empty
    isEmptyObject: function( obj ) {
      for ( var key in obj ) {
        if ( obj.hasOwnProperty( key ) ) {
          return false;
        }
      }

      return true;
    }
  };

  // -------------------- Sorters --------------------

  var sorters = {
    // Sort lowest to highest
    alphanumeric: function( a, b ) {
      return a > b ? 1 : a < b ? -1 : 0;
    },
    // Sort top down, then left to right
    downwardLeftToRight: function( a, b ) {
      return a.y - b.y || a.x - b.x;
    },
    // Sort left to right, then top down
    rightwardTopToBottom: function( a, b ) {
      return a.x - b.x || a.y - b.y;
    }
  };

  // -------------------- Parsers --------------------

  var parsers = {
    // Parse a string and return an integer
    parseInt: function( val ) {
      return parseInt( val, 10 );
    },
    // Parse a string and return a floating point nuumber
    parseFloat: function( val ) {
      return parseFloat( val );
    }
  };

  // -------------------- Events --------------------

  var event = {
    // Attach an event handler to a listener
    bind: function( listener, type, callback ) {
      if ( listener.addEventListener ) {
        listener.addEventListener( type, callback, false );
      }
    },
    // Remove an attached event handler from a listener
    unbind: function( listener, type, callback ) {
      if ( listener.removeEventListener ) {
        listener.removeEventListener( type, callback, false );
      }
    },
    // Trigger event attached to the listener
    emit: function( type, listener ) {
      if ( listener.dispatchEvent ) {
        var event = new Event( type );
        listener.dispatchEvent( event );
      }
    }
  };

  // -------------------- Rect --------------------
  
  /** 
   * @constructor
   * @param {Number} x
   * @param {Number} y
   * @param {Number} width
   * @param {Number} height
   */
  function Rect( x, y, width, height ) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
  }

  /**
   * Determine whether this Rect wholly encloses another Rect
   *
   * @param {Rect} rect
   * returns {Boolean}
   */
  Rect.prototype._contains = function( rect ) {
    return this.x <= rect.x &&
           this.y <= rect.y &&
           this.x + this.width >= rect.x + rect.width &&
           this.y + this.height >= rect.y + rect.height;
  };

  /**
   * Determine whether this Rect intersects another Rect applying De Morgan's laws
   *
   * @param {Rect} rect
   * returns {Boolean}
   */
  Rect.prototype._overlaps = function( rect ) {
    return this.x < rect.x + rect.width &&
           this.x + this.width > rect.x &&
           this.y < rect.y + rect.height &&
           this.y + this.height > rect.y;
  };

  /**
   * Determine whether this Rect can fit another Rect
   *
   * @param {Rect} rect
   * returns {Boolean}
   */
  Rect.prototype._fits = function( rect ) {
    return this.width >= rect.width && 
           this.height >= rect.height;
  };

  /**
   * Obtain Rects representing the area around this Rect
   *
   * @param {Rect} rect
   * returns {Boolean}
   */
  Rect.prototype._getRectsAround = function( rect ) {
    // Return false if no overlap
    if ( !this._overlaps( rect ) ) {
      return false;
    }

    var spaces = [];

    // Add space to the right
    if ( this.x + this.width > rect.x + rect.width ) {
      var space = new Rect( rect.x + rect.width, this.y, this.x + this.width - rect.x - rect.width, this.height );
      spaces.push( space );
    }

    // Add space to the bottom
    if ( this.y + this.height > rect.y + rect.height ) {
      var space = new Rect( this.x, rect.y + rect.height, this.width, this.y + this.height - rect.y - rect.height );
      spaces.push( space );
    }

    // Add space to the top
    if ( this.y < rect.y ) {
      var space = new Rect( this.x, this.y, this.width, rect.y - this.y );
      spaces.push( space );
    }

    // Add space to the left
    if ( this.x < rect.x ) {
      var space = new Rect( this.x, this.y, rect.x - this.x, this.height );
      spaces.push( space );
    }
    
    return spaces;
  };

  // -------------------- Item --------------------
  
  /**
   * @constructor
   * @param {Element} element
   * @param {Object} options
   */
  function Item( element, options ) {
    this.element = element;
    this.defaults = {
      duration: 500,
      easing: 'ease',
      itemStyle: {
        position: 'absolute'
      },
      hiddenStyle: {
        opacity: 0,
        transform: 'scale(0.001)'
      },
      visibleStyle: {
        opacity: 1,
        transform: 'scale(1)'
      }
    };
    this.position = {
      x: 0,
      y: 0
    };

    this.options = utils.extend( {}, this.defaults );
    this._options( options );

    this._create();
  }

  /**
   * Create item
   */
  Item.prototype._create = function() {
    this._transition = {
      property: {},
      clean: {},
      end: {}
    };
    this.sortData = {};

    this.getSize();
    this.css( this.options.itemStyle );
  };

  /**
   * Overwrite default item options
   *
   * @param {Object} options
   */
  Item.prototype._options = function( options ) {
    // Do not continue if there are no options
    if ( !options ) {
      return;
    }
    // If option exists, overwrite option
    for ( var option in options ) {
      if ( this.options.hasOwnProperty( option ) ){
        this.options[ option ] = options[ option ];
      }
    }
  };

  /**
   * Remove item
   */
  Item.prototype._remove = function() {
    // Remove display: none
    this.css({ display: '' });
    this.transition({
      to: this.options.hiddenStyle,
      end: {
        opacity: this._onRemoveTransitionEnd
      }
    });
  };

  /**
   * Remove item from the DOM after transition end event
   */
  Item.prototype._onRemoveTransitionEnd = function() {
    this.element.parentNode.removeChild( this.element );
    event.emit( 'remove', this.element );
  };

  /**
   * Reveal item
   */
  Item.prototype._reveal = function() {
    delete this.hidden;
    // Remove display: none
    this.css({ display: '' });
    this.transition({
      from: this.options.hiddenStyle,
      to: this.options.visibleStyle,
      end: {
        opacity: this._onRevealTransitionEnd
      }
    });
  };
  
  /**
   * Item is fully revealed after transition end event
   */
  Item.prototype._onRevealTransitionEnd = function() {
    if ( !this.hidden ) {
      event.emit( 'reveal', this.element );
    }
  };

  /**
   * Hide item
   */
  Item.prototype._hide = function() {
    this.hidden = true;
    // Remove display: none
    this.css({ display: '' });
    this.transition({
      from: this.options.visibleStyle,
      to: this.options.hiddenStyle,
      end: {
        opacity: this._onHideTransitionEnd
      }
    });
  };

  /**
   * Do not display item after transition end event
   */
  Item.prototype._onHideTransitionEnd = function() {
    if ( this.hidden ) {
      this.css({ display: 'none' });
      event.emit( 'hide', this.element );
    }
  };

  /**
   * Move item from its current position to x & y coordinates
   *
   * @param {Number} x - horizontal position
   * @param {Number} y - vertical position
   */
  Item.prototype._moveTo = function( x, y ) {
    this.setPosition( x, y );
    this.layoutPosition();
  };

  /**
   * Transition item from its current position to x & y coordinates
   *
   * @param {Number} x - horizontal position
   * @param {Number} y - vertical position
   */
  Item.prototype._transitionTo = function( x, y ) {
    this.getPosition();

    // Save current position
    var position = {
      x: this.position.x,
      y: this.position.y
    };

    // Save end position
    this.setPosition( x, y );

    // Lay out item if did not move and is not transitioning
    if ( x === position.x && y === position.y && !this._transition.ing ) {
      this.layoutPosition();
      return;
    }

    // Translate item from its current position
    // to its new position in the layout
    var transition = {
      x: x - position.x,
      y: y - position.y
    }

    this.transition({
      to: {
        transform: 'translate3d(' + transition.x + 'px, ' + transition.y + 'px, 0px)'
      },
      end: {
        transform: this.layoutPosition
      }
    });
  };

  /**
   * Trigger after item has completed a transition
   *
   * @param {Event} e - event
   */
  Item.prototype._onTransitionEnd = function( e ) {
    // Prevent event bubbling
    if ( e.target !== this.element ) {
      return
    }

    var transition = this._transition;
    // Get transitionend event property name
    var prop = e.propertyName;
    // Remove the property that has completed transitioning
    delete transition.property[ prop ];
    
    // Check if all properties have completed transitioning
    if ( utils.isEmptyObject( transition.property ) ) {
      this.disableTransition();
    }

    // Clean style for the transitioning property
    if ( prop in transition.clean ) {
      this.element.style[ prop ] = '';
      delete transition.clean[ prop ];
    }

    // Trigger callback
    if ( prop in transition.end ) {
      transition.end[ prop ].call( this );
      delete transition.end[ prop ];
    }

    event.emit( 'transition', this.element );
  };

  /**
   * Update item transition delay
   *
   * @param {Number} time - Delay in milliseconds
   */
  Item.prototype._updateDelay = function( time ) {
    var delay = isNaN( time ) ? 0 : time;
    this.options.delay = delay;
  };

  /**
   * Update sort data
   *
   * @param {Object} sorters
   */
  Item.prototype._updateSortData = function( sorters ) {
    this.sortData.id = this.id;
    this.sortData.original = this.id;
    this.sortData.random = Math.random();

    for ( var key in sorters ) {
      var sorter = sorters[ key ];
      this.sortData[ key ] = sorter( this.element, this );
    }
  };

  /**
   * Get item size
   */
  Item.prototype.getSize = function() {
    this.size = getSize( this.element );
  };

  /**
   * Get item position
   */
  Item.prototype.getPosition = function() {
    this.position = getPosition( this.element );
  };

  /**
   * Set item position
   * 
   * @param {Number} x - horizontal position
   * @param {Number} y - vertical position
   */
  Item.prototype.setPosition = function( x, y ) {
    this.position.x = x;
    this.position.y = y;
  };

  /**
   * Lay out item in its current position
   */
  Item.prototype.layoutPosition = function() {
    var style = {
      top: this.position.y + 'px',
      left: this.position.x + 'px'
    };

    this.css( style );
    event.emit( 'layout', this.element );
  };

  /**
   * Trigger specific method for event type
   *
   * @param {Event} event
   */
  Item.prototype.handleEvent = function( event ) {
    switch ( event.type ) {
      case 'transitionend':
        this._onTransitionEnd( event );
        break;
    }
  };

  /**
   * Set item style
   *
   * @param {Object} props - style
   */
  Item.prototype.css = function( props ) {
    for( var prop in props ) {
      this.element.style[ prop ] = props[ prop ];
    }
  };

  /**
   * Transition item style
   * 
   * @param {Object} args - arguments
   *   @param {Object} to - style to transition to
   *   @param {Object} from - style to start transition from
   *   @param {Function} end - callback
   */
  Item.prototype.transition = function( args ) {
    // Redirect to no transition if no transition duration
    if ( !parseFloat( this.options.duration ) ) {
      this.noTransition( args );
      return;
    }

    var transition = this._transition;

    // Keep track of the callback
    for ( var prop in args.end ) {
      transition.end[ prop ] = args.end[ prop ];
    }

    // Keep track of properties that are transitioning
    for ( var prop in args.to ) {
      transition.property[ prop ] = true;
      // Keep track of properties to clean up once transition has completed 
      transition.clean[ prop ] = true;
    }

    // Set from styles.
    // HACK Force redraw between transitions
    if ( args.from ) {
      this.css( args.from );
      this.getSize();
    }

    this.enableTransition();
    // Set transitioning styles
    this.css( args.to );

    this._transition.ing = true;
  };

  /**
   * Set item style, no transition. Trigger callback
   * 
   * @param {Object} args - arguments
   *   @param {Object} to - style to transition to
   *   @param {Function} end - callback
   */
  Item.prototype.noTransition = function( args ) {
    this.css( args.to );
    // Clean styles
    var style = {};
    
    for ( var prop in args.to ) {
      style[ prop ] = '';
    }

    this.css( style );
    // Trigger callback
    for ( var prop in args.end ) {
      args.end[ prop ].call( this );
    }
  };

  /**
   * Enable item transition
   */
  Item.prototype.enableTransition = function() {
    // HACK Changing properties during a transition
    // cause the transition to jump
    if ( this._transition.ing ) {
      return;
    }

    this.css({
      transitionProperty: 'opacity, transform',
      transitionDuration: this.options.duration + 'ms',
      transitionTimingFunction: this.options.easing,
      transitionDelay: this.options.delay + 'ms'
    });

    // Listen for transition end event
    this.element.addEventListener( 'transitionend', this, false );
  };

  /**
   * Disable item transition
   */
  Item.prototype.disableTransition = function() {
    // Clear transition
    this.css({
      transitionProperty: '',
      transitionDuration: '',
      transitionTimingFunction: '',
      transitionDelay: ''
    });

    // Remove transition end event listener
    this.element.removeEventListener( 'transitionend', this, false );
    this._transition.ing = false;
  };

  /**
   * Remove and disable item
   */
  Item.prototype.destroy = function() {
    this.css({
      position: '',
      top: '',
      left: '',
      opacity: '',
      transform: '',
      transition: ''
    });
  };

  // -------------------- Layout Modes --------------------

  /**
   * Grid
   */
  function Grid() {}

  Grid.prototype._resetLayout = function() {
    this.x = 0;
    this.y = 0;
    this.maxX = 0;
    this.maxY = 0;

    this._resetSortDirection();
    this._resetSpaces();
  };

  Grid.prototype._getItemPosition = function( item ) {
    var rect = new Rect( this.x, this.y, item.size.outerWidth, item.size.outerHeight );

    this.spaces.some( function( space ) {
      if ( space._fits( rect ) ) {
        this._placeInSpace( rect, space );
        return true;
      }
    }, this );

    var x = this.x;
    var y = this.y;

    this.maxX = Math.max( this.maxX, rect.x + rect.width );
    this.maxY = Math.max( this.maxY, rect.y + rect.height );

    return { x: x, y: y };
  };

  Grid.prototype._getContainerSize = function() {
    if ( this.options.horizontal ) {
      return { width: this.maxX };
    } else {
      return { height: this.maxY };
    }
  };

  Grid.prototype._resetSortDirection = function() {
    if ( this.options.horizontal ) {
      this.size.width = Number.POSITIVE_INFINITY;
      this.sortDirection = 'rightwardTopToBottom';
    } else {
      this.size.height = Number.POSITIVE_INFINITY;
      this.sortDirection = 'downwardLeftToRight';
    }

    this.sorter = sorters[ this.sortDirection ];
  };

  Grid.prototype._resetSpaces = function() {
    var space = new Rect( this.x, this.y, this.size.width, this.size.height );
    
    this.spaces = [];
    this.spaces.push( space );
  };

  Grid.prototype._placeInSpace = function( rect, space ) {
    this.x = rect.x = space.x;
    this.y = rect.y = space.y;

    this._splitSpace( rect );
  };

  Grid.prototype._splitSpace = function( rect ) {
    var spaces = [];

    this.spaces.forEach( function( space ) {
      var rects = space._getRectsAround( rect );
      if ( rects ) {
        spaces.push.apply( spaces, rects );
      } else {
        spaces.push( space );
      }
    });

    this.spaces = spaces;
    this._mergeSortSpaces();
  };

  Grid.prototype._mergeSortSpaces = function() {
    this._mergeSpaces();
    this.spaces.sort( this.sorter );
  };

  Grid.prototype._mergeSpaces = function() {
    this.spaces.forEach( function( space ) {
      if ( !space ) {
        return;
      }

      this.spaces.forEach( function( rect ) {
        if ( rect === space ) {
          return;
        }

        if ( space._contains( rect ) ) {
          this._removeSpace( rect );
        }
      }, this );
    }, this )
  };

  Grid.prototype._removeSpace = function( rect ) {
    this.spaces.some( function( space ) {
      var index = this.spaces.indexOf( rect );

      if ( space === rect ) {
        this.spaces.splice( index, 1 );
        return true;
      }
    }, this );
  };

  /**
   * Rows
   */
  function Rows() {}

  Rows.prototype._resetLayout = function() {
    this.x = 0;
    this.y = 0;
    this.maxY = 0;
  };

  Rows.prototype._getItemPosition = function( item ) {
    if ( this.x !== 0 && this.x + item.size.outerWidth > this.size.width ) {
      this.x = 0;
      this.y = this.maxY;
    }

    var x = this.x;
    var y = this.y;

    this.x += item.size.outerWidth;
    this.maxY = Math.max( this.maxY, this.y + item.size.outerHeight );

    return { x: x, y: y };
  };

  Rows.prototype._getContainerSize = function() {
    return { height: this.maxY };
  };

  /**
   * Columns
   */
  function Columns() {}

  Columns.prototype._resetLayout = function() {
    this.x = 0;
    this.y = 0;
    this.maxX = 0;
  };

  Columns.prototype._getItemPosition = function( item ) {
    if ( this.y !== 0 && this.y + item.size.outerHeight > this.size.height ) {
      this.x = this.maxX;
      this.y = 0;
    }

    var x = this.x;
    var y = this.y;

    this.y += item.size.outerHeight;
    this.maxX = Math.max( this.maxX, this.x + item.size.outerWidth );

    return { x: x, y: y };
  };

  Columns.prototype._getContainerSize = function() {
    return { width: this.maxX };
  };

  /**
   * Horizontal
   */
  function Horizontal() {}

  Horizontal.prototype._resetLayout = function() {
    this.x = 0;
  };

  Horizontal.prototype._getItemPosition = function( item ) {
    this.y = 0;

    var x = this.x;
    var y = this.y;
    
    this.x += item.size.outerWidth;

    return { x: x, y: y };
  };

  Horizontal.prototype._getContainerSize = function() {
    return { width: this.x };
  };

  /**
   * Vertical
   */
  function Vertical() {}

  Vertical.prototype._resetLayout = function() {
    this.y = 0;
  };

  Vertical.prototype._getItemPosition = function( item ) {
    this.x = 0;

    var x = this.x;
    var y = this.y;
    
    this.y += item.size.outerHeight;

    return { x: x, y: y };
  };

  Vertical.prototype._getContainerSize = function() {
    return { height: this.y };
  };

  // -------------------- Magnet --------------------

  /**
   * @constructor
   * @param {Element} element
   * @param {Object} options
   */
  function Magnet( element, options ) {
    this.element = element;
    this.defaults = {
      containerStyle: {
        position: 'relative'
      },
      initLayout: true,
      resize: true,
      resizeContainer: true,
      sortAscending: true,
      layoutMode: 'grid'
    };

    this.options = utils.extend( {}, this.defaults );
    this._options( options );
    this._create();
    
    // Layout
    if ( this.options.initLayout ) {
      this.layout();
    }
  }

  /**
   * Create the layout & fill with items
   */
  Magnet.prototype._create = function() {
    // Global unique item identifier
    this.guid = 0;
    
    // Functions to sort items
    this.sorters = {};
    this._getSorters();
    
    // Keep track of sort history
    this.sortHistory = [ 'original' ];

    this.reloadItems();
    this.css( this.options.containerStyle );

    // Bind resize method
    if ( this.options.resize ) {
      this._bindResize();
    }
  };

  /**
   * Overwrite default options
   *
   * @param {Object} options
   */
  Magnet.prototype._options = function( options ) {
    // Do not continue if there are no options
    if ( !options ) {
      return;
    }
    // Set any option passed as argument
    this.options = utils.extend( this.options, options );
  };

  /**
   * Initialization
   */
  Magnet.prototype._init = function() {
    this.arrange();
  };

  /**
   * Turn elements into Items
   *
   * @param {NodeList} elements
   * @return {Array} items - collection of Items
   */
  Magnet.prototype._itemize = function( elements ) {
    // Turn elements to array
    var elems = utils.toArray( elements );
    elems = this._filterFindElements( elems );

    var items = elems.map( function( elem, i ) {
      var item = new Item( elem, this.options );
      item.id = ++this.guid;

      return item;
    }, this );

    this._updateItemsSortData( items );
    return items;
  };

  /**
   * Set layout mode
   */ 
  Magnet.prototype._mode = function() {
    // Reset layout
    this._reloadLayout();

    switch ( this.options.layoutMode ) {
      case 'grid':
        utils.extend( Magnet.prototype, Grid.prototype );
        break;
      
      case 'rows':
        utils.extend( Magnet.prototype, Rows.prototype );
        break;
      
      case 'columns':
        utils.extend( Magnet.prototype, Columns.prototype );
        break;
      
      case 'vertical':
        utils.extend( Magnet.prototype, Vertical.prototype );
        break;
      
      case 'horizontal':
        utils.extend( Magnet.prototype, Horizontal.prototype );
        break;
      
      default:
        throw new Error( 'No layout mode: ' + this.options.layoutMode );
        break;
    }
  };

  /**
   * Filter items
   *
   * @param {Array} items
   * @return {Object} filtered - collections of items
   *   @return {Array} matched - items that match filter
   *   @return {Array} reveal  - items that need to reveal
   *   @return {Array} hide    - items that need to hide
   */
  Magnet.prototype._filter = function( items ) {
    var filter = this.options.filter || '*';

    // Collections of item and elements to be processed
    var filtered = {
      matched: [],
      reveal: [],
      hide: []
    };

    // Test each item
    items.forEach( function( item ) {
      var match = this._getFilterTest( item, filter );
      // Add items if they match the filter
      if( match ) {
        filtered.matched.push( item );
      }
      // Add item element to additional group if need to be hidden or revealed
      if ( match && item.hidden ) {
        filtered.reveal.push( item );
        // filtered.reveal.push( item.element );
      } else if ( !match && !item.hidden ) {
        filtered.hide.push( item );
        // filtered.hide.push( item.element );
      }
    }, this );

    return filtered;
  };

  /**
   * Hide & reveal items that change its visibility after filtering
   *
   * @param {Object} filtered - collections of items
   */
  Magnet.prototype._hideReveal = function( filtered ) {
    this._revealItems( filtered.reveal );
    this._hideItems( filtered.hide );
  };

  /**
   * Reveal a collection of items
   *
   * @param {Array} items
   */
  Magnet.prototype._revealItems = function( items ) {
    this._emitCompleteOnItems( 'reveal', items );  
    // Do not continue if no items
    if ( !items || !items.length ) {
      return;
    }
    
    var stagger = this._updateStagger();
    items.forEach( function( item, i ) {
      item._updateDelay( i * stagger );
      item._reveal();
    });
  };

  /**
   * Hide a collection of items
   *
   * @param {Array} items
   */
  Magnet.prototype._hideItems = function( items ) {
    this._emitCompleteOnItems( 'hide', items ); 
    // Do not continue if no items
    if ( !items || !items.length ) {
      return;
    }
    
    var stagger = this._updateStagger();
    items.forEach( function( item, i ) {
      item._updateDelay( i * stagger );
      item._hide();
    });
  };

  /**
   * Filter, layout & reveal appended or prepended items
   *
   * @param {Array} items
   */
  Magnet.prototype._filterRevealAdded = function( items ) {
    // Filter added items
    var filtered = this._filter( items );

    this._hideItems( filtered.hide );
    // Layout items, no transition
    this.layoutItems( filtered.matched, true );
    this._revealItems( filtered.matched );
    
    return filtered.matched;
  };

  /**
   * Sort items
   */
  Magnet.prototype._sort = function() {
    var sortBy = this.options.sortBy;
    // Do not sort if option is not set
    if ( !sortBy ) {
      return;
    }
    
    // Turn all sort by values to array.
    // Concat sort by values and original order.
    // Use original order values to guarantee sort stability
    var sortBys = utils.toArray( sortBy );
    sortBys = sortBys.concat( 'original' );

    // Function to sort filtered items
    var sorter = getItemSorter( sortBys, this.options.sortAscending );
    this.filteredItems.sort( sorter );

    // Keep track of sort history, just for information.
    // Newest goes first, oldest goes last
    if ( this.sortHistory.indexOf( sortBy ) !== 0 ) {
      this.sortHistory.unshift( sortBy );
    }
  };

  /**
   * Layout items
   */
  Magnet.prototype._layout = function() {
    var instant = this._getIsInstant();

    this._resetLayout();
    this._layoutItems( this.filteredItems, instant );
    this._postLayout();

    this._layoutInited = true;
  };

  /**
   * Layout a collection of items
   *
   * @param {Array} items
   * @param {Boolean} instant - Disable transition
   */
  Magnet.prototype._layoutItems = function( items, instant ) {
    var queue = items.map( function( item ) {
      // Get item size to ensure its correct position in the layout,
      // in case its size has changed
      item.getSize();

      var position = this._getItemPosition( item );
      // Enqueue
      position.item = item;
      position.instant = instant;

      return position;
    }, this );

    this._emitCompleteOnItems( 'layout', items );
    this._processLayoutQueue( queue );
  };

  /**
   * Iterate over array and position each item in the layout
   *
   * @param {Array} queue
   */
  Magnet.prototype._processLayoutQueue = function( queue ) {
    queue.forEach( function( obj, i ) {
      this._positionItem( obj.item, obj.x, obj.y, obj.instant, i );
    }, this );
  };

  /**
   * Position an item in the x & y coordinates of the layout
   *
   * @param {Item} item
   * @param {Number} x
   * @param {Number} y
   * @param {Boolean} instant
   * @param {Number} i
   */
  Magnet.prototype._positionItem = function( item, x, y, instant, i ) {
    var stagger = this._updateStagger();
    if ( instant ) {
      item._moveTo( x, y );
    } else {
      item._updateDelay( i * stagger );
      item._transitionTo( x, y );
    }
  };

  /**
   * Logic after each layout
   */
  Magnet.prototype._postLayout = function() {
    this._resizeContainer();
  };

  /**
   * Resize layout container
   */
  Magnet.prototype._resizeContainer = function() {
    if ( !this.options.resizeContainer ) {
      return;
    }

    var size = this._getContainerSize();

    if ( size ) {
      this._setContainerSize( size.width, size.height );
    }
  };

  /**
   * Set layout container size
   *
   * @param {Number} width
   * @param {Number} height
   */
  Magnet.prototype._setContainerSize = function( width, height ) {
    if ( width ) {
      this.size.width = width;
    } else {
      this.size.height = height;
    }

    this.css({
      width: width + 'px',
      height: height + 'px'
    }); 
  };

  /**
   * Bind layout to window resizing
   */
  Magnet.prototype._bindResize = function() {
    // Bind just one listener
    if ( this.resizeBound ) {
      return;
    }

    event.bind( window, 'resize', this );
    this.resizeBound = true;
  };

  /**
   * Unbind layout to window resizing
   */
  Magnet.prototype._unbindResize = function() {
    // Unbind if listener was bound
    if ( this.resizeBound ) {
      event.unbind( window, 'resize', this );
    }

    this.resizeBound = false;
  };

  /**
   * Trigger on every resize
   *
   * @param {Event} event
   */
  Magnet.prototype._onResize = function( event ) {
    var _this = this;
    
    if ( this.timeout ) {
      clearTimeout( this.timeout );
    }

    function delayed() {
      _this._resize();
      delete _this.timeout;
    }

    this.timeout = setTimeout( delayed, 100 );
  };

  /**
   * Debounced, layout on resize
   */
  Magnet.prototype._resize = function() {
    // Do not trigger if resize was unbound
    // or size did not change
    if ( !this.resizeBound || !this._resizeLayout() ) {
      return;
    }

    this.layout();
  };

  /**
   * Resize layout if size has changed
   *
   * @return {Boolean}
   */
  Magnet.prototype._resizeLayout = function() {
    var size = getSize( this.element );

    // If size did change, update layout size 
    // and return that has changed
    if ( this.size !== size ) {
      this.getSize();
      return true;
    }

    return false;
  };

  /**
   * Remove leftover properties and reset layout size
   */
  Magnet.prototype._reloadLayout = function() {
    delete this.x;
    delete this.y;
    delete this.maxX;
    delete this.maxY;
    delete this.sortDirection;
    delete this.sorter;
    delete this.spaces;

    this._resetLayoutSize();
  };

  /**
   * Reset layout size
   */
  Magnet.prototype._resetLayoutSize = function() {
    this.css({
      width: '',
      height: ''
    });

    this.getSize();
  };

  /**
   * Emit asynchronous event on items event complete
   */
  Magnet.prototype._bindArrangeComplete = function() {
    var types = {
      layoutComplete: false,
      hideComplete: false,
      revealComplete: false
    };

    var _this = this;
    // Arrange complete if 3 events are complete
    function arrangeComplete() {
      for ( var type in types ) {
        if ( !types[ type ] ) {
          return;
        }
      }
      _this._onItemsComplete( 'arrange' );
    }
    
    // Create an array for variable scope
    var typesComplete = [];
    for ( var type in types ) {
      typesComplete.push( type );
    }

    // Listen to layoutComplete, hideComplete & revealComplete.
    // Trigger arrangeComplete on each event complete
    typesComplete.forEach( function( type ) {
      var callback = function() {
        types[ type ] = true;
        arrangeComplete.call( this );
        event.unbind( _this.element, type, callback );
      };
      event.bind( this.element, type, callback );
    }, this );
  };

  /**
   * Emit complete on a collection of items events
   *
   * @param {String} type - event name
   * @param {Array} items
   */
  Magnet.prototype._emitCompleteOnItems = function( type, items ) {
    if ( !items || !items.length ) {
      this._onItemsComplete( type );
      return;
    }

    var _this = this;
    var i = 0;
    function tick() {
      i++;
      if ( i === items.length ) {
        _this._onItemsComplete( type );
      }
    }

    items.forEach( function( item ) {
      var callback = function() {
        tick.call( this );
        event.unbind( item.element, type, callback );
      };
      event.bind( item.element, type, callback );
    });
  };

  /**
   * Emit asynchronous event on items event complete
   *
   * @param {String} type - event name
   */
  Magnet.prototype._onItemsComplete = function( type ) {
    event.emit( type + 'Complete', this.element );
  };

  /**
   * Do not animate first layout or any other layouts
   */
  Magnet.prototype._getIsInstant = function() {
    var instant = this.options.layoutInstant !== undefined ? this.options.layoutInstant :
                  !this._layoutInited;

    this._layoutInstant = instant;
    return instant;
  };

  /**
   * Get items to be laid out
   *
   * @param {Array} items
   * @return {Array}
   */
  Magnet.prototype._getLayoutItems = function( items ) {
    return items.filter( function( item ) {
      return !item.hidden;
    });
  };

  /**
   * Get whether an item matches a filter or not
   *  
   * @param {String} filter
   * @return {Boolean}
   */
  Magnet.prototype._getFilterTest = function( item, filter ) {
    // Use filter as function
    if ( typeof filter == 'function' ) {
      return filter( item.element );
    }

    // Use filter as selector string by default
    return matchesSelector( item.element, filter );
  };

  /**
   * Get a sorter for each sort key
   */
  Magnet.prototype._getSorters = function() {
    var sortData = this.options.sortData;
    
    for ( var key in sortData ) {
      var sorter = sortData[ key ];
      this.sorters[ key ] = mungeSorter( this.element.children, sorter );
    }
  };

  /**
   * Get a elements from a collection of Items
   *
   * @param {Array} items - Items
   * @return {Array} - Elements
   */
  Magnet.prototype._getElements = function( items ) {
    return items.map( function( item ) {
      return item.element;
    });
  };

  /**
   * Get the value set for an option of a random item of the collection
   *
   * @param {Object} option
   * @return {Number or String or Object}
   */
  Magnet.prototype._getItemOption = function( option ) {
    var random = Math.floor( Math.random() * this.items.length );
    // Get a random item of the collection
    var item = this.items[ random ];
    // Return item option value
    return item.options[ option ];
  };

  /**
   * Update options for a collection of items
   *
   * @param {Object} option
   */
  Magnet.prototype._setItemsOptions = function( options ) {
    this.items.forEach( function( item ) {
      item._options( options );
    });
  };

  /**
   * Get items to be used in the layout
   *
   * @param {Array} elements
   * @return {Array} elems
   */
  Magnet.prototype._filterFindElements = function( elements ) {
    return elements.filter( function( elem ) {
      // Do not proceed if element is not an element
      if ( !( elem instanceof HTMLElement ) ) {
        return;
      }
      // Add element if no selector
      if ( !this.options.itemSelector ) {
        return elem;
      }
      // Add element if matches selector
      if ( matchesSelector( elem, this.options.itemSelector ) ) {
        return elem;
      }
    }, this );
  };

  /**
   * Update items sort data
   *
   * @param {Array} items
   */
  Magnet.prototype._updateItemsSortData = function( items ) {  
    // Do not update if no items
    if ( !items ) {
      return;
    }

    items.forEach( function( item ) {
      item._updateSortData( this.sorters );
    }, this );
  };

  /**
   * Set stagger from option
   *
   * @return {Number} stagger
   */
  Magnet.prototype._updateStagger = function() {
    var stagger = this.options.stagger;
    if ( !stagger ) {
      this.stagger = 0;
      return;
    }

    this.stagger = stagger;
    return stagger;
  };

  /**
   * Remove an item from the items collection
   *
   * @param {Array} item
   */
  Magnet.prototype._removeItem = function( item ) {
    var index = this.items.indexOf( item );
    if ( index !== -1 ) {
      this.items.splice( index, 1 );
    }
  };

  /**
   * Trigger function without transition
   *
   * @param {Function} fn
   * @param {Object} args
   */
  Magnet.prototype._noTransition = function( fn, args ) {
    // Save transition duration value
    var duration = this._getItemOption( 'duration' );

    // Update item options, set duration to 0
    this._setItemsOptions({ duration: 0 });
    // Call the function
    fn.call( this, args );
    // Restore item options, set duration to previous value
    this._setItemsOptions({ duration: duration });
  };

  /**
   * Get the size of the layout
   */
  Magnet.prototype.getSize = function() {
    this.size = getSize( this.element );
  };

  /**
   * Trigger specific method for event type
   *
   * @param {Event} event
   */
  Magnet.prototype.handleEvent = function( event ) {
    switch ( event.type ) {
      case 'resize':
        this._onResize( event );
        break;
    }
  };

  /**
   * Set the CSS of an Item
   *
   * @param {Object} props - style
   */
  Magnet.prototype.css = function( props ) {
    for( var prop in props ) {
      this.element.style[ prop ] = props[ prop ];
    }
  };

  // -------------------- Methods --------------------

  /**
   * Add items to the layout
   *  
   * @param {Array or NodeList or Element} elements
   * @returns {Array} items
   */
  Magnet.prototype.addItems = function( elements ) {
    var items = this._itemize( elements );
    // Add items to collection
    if ( items.length ) {
      this.items = this.items.concat( items );
    }
    
    return items;
  };

  /**
   * Lay out items added to the end of the layout
   *  
   * @param {Array or NodeList or Element} elements
   */
  Magnet.prototype.append = function( elements ) {
    // Do not continue if no elements
    if ( !elements ) {
      return;
    }
    
    var items = this.addItems( elements );
    // Filter added items
    var filtered = this._filterRevealAdded( items );
    // Add to filtered items
    this.filteredItems = this.filteredItems.concat( filtered );
  };

  /**
   * Lay out items added to the beginning of the layout
   *  
   * @param {Array or NodeList or Element} elements
   */
  Magnet.prototype.prepend = function( elements ) {
    // Do not continue if no elements
    if ( !elements ) {
      return;
    }
    
    var items = this._itemize( elements );
    // Add items to beginning of collection
    this.items = items.concat( this.items ); 
    // Start a new layout
    this._resetLayout();
    // Filter added items
    var filtered = this._filterRevealAdded( items );
    // Layout previous filtered items
    this.layoutItems( this.filteredItems );
    // Add items to beginning of filtered items
    this.filteredItems = filtered.concat( this.filteredItems );
  };

  /**
   * Filter, sort & layout appended items
   *
   * @param {Array or NodeList or Element} elements
   */
  Magnet.prototype.insert = function( elements ) {
    // Do not continue if no elements
    if ( !elements ) {
      return;
    }
    
    var items = this.addItems( elements );
    // Append items element
    items.forEach( function( item ) {
      this.element.appendChild( item.element );
    }, this );
    
    // Filter new items
    var filtered = this._filter( items ).matched;
    // Save transition duration value
    var duration = this._getItemOption( 'duration' );
    
    // Set no transition
    items.forEach( function( item ) {
      item._options({ duration: 0 });
    });

    this.arrange();

    // Reset items transition
    items.forEach( function( item ) {
      item._options({ duration: duration });
    });
   
    this._revealItems( filtered );
  };

  /**
   * Remove item from the layout and the DOM
   *
   * @param {Array or NodeList or Element} elements
   */
  Magnet.prototype.remove = function( elements ) {
    var items = this.getItems( elements );
    this._emitCompleteOnItems( 'remove', items );
    
    // Do not continue if no items
    if ( !items || items.length ) { 
      return;
    }
    
    items.forEach( function( item ) {
      item._remove();
      this._removeItem( item );
    }, this );

    this.arrange();
  };

  /**
   * Goes through all items of the layout
   */
  Magnet.prototype.reloadItems = function() {
    this.guid = 0;
    this.items = this._itemize( this.element.children );
  };

  /**
   * Get item, given element
   *  
   * @param {Element} element
   * @return {Item} item
   */
  Magnet.prototype.getItem = function( element ) {
    for ( var i = 0; i < this.items.length; i++ ) {
      var item = this.items[i]
      if ( item.element === element ) {
        return item;
      }
    }
  };
  
  /**
   * Get a collection of items, given elements
   *
   * @param {Array or Element or NodeList} elements
   * @return {Array} items
   */
  Magnet.prototype.getItems = function( elements ) {
    var items = [];
    elements = utils.toArray( elements );
    elements.forEach( function( element ) {
      var item = this.getItem( element );
      if ( item ) {
        items.push( item );
      }
    }, this );

    return items;
  };

  /**
   * Get items elements
   *
   * @return {Array} items
   */
  Magnet.prototype.getItemsElements = function() {
    return this.items.map( function( item ) {
      return item.element;
    });
  };

  /**
   * Get items matching active filter
   *
   * @return {Array} items
   */
  Magnet.prototype.getFilteredItems = function() {
    return this.filteredItems.map( function( item ) {
      return item;
    });
  };

  /**
   * Get items elements matching active filter
   *
   * @return {Array} items
   */
  Magnet.prototype.getFilteredItemsElements = function() {
    return this.filteredItems.map( function( item ) {
      return item.element;
    });
  };

  /**
   * Filter, sort & layout items
   *
   * @param {Object} options
   */
  Magnet.prototype.arrange = function( options ) {
    // Set options passed as arguments
    this._options( options );
    this._mode();
    this._bindArrangeComplete();

    var instant = this._getIsInstant();
    // Filter items
    var filtered = this._filter( this.items );
    this.filteredItems = filtered.matched;

    if ( instant ) {
      this._noTransition( this._hideReveal, filtered );
    } else {
      this._hideReveal( filtered );
    }

    this._sort();
    this._layout();
  };

  /**
   * Reveal items
   *
   * @param {Array or NodeList or Element} elements
   */
  Magnet.prototype.reveal = function( elements ) {
    var items = this.getItems( elements );
    this._revealItems( items );
    // Update filtered items with revealed items
    var filtered = this._getLayoutItems( this.items );
    this.filteredItems = filtered;
  };

  /**
   * Hide items
   *
   * @param {Array or NodeList or Element} elements
   */
  Magnet.prototype.hide = function( elements ) {
    var items = this.getItems( elements );
    this._hideItems( items );
    // Update filtered items without hidden items
    var filtered = this._getLayoutItems( this.items );
    this.filteredItems = filtered;
  }; 

  /**
   * Layout items
   */
  Magnet.prototype.layout = function() {
    // Filter, sort & layout if first time
    if ( !this._layoutInited && this.options.initLayout ) {
      this.arrange();
      return;
    }

    this._layout();
  };

  /**
   * Layout a collection of items
   *
   * @param {Array} items - collection of Items
   * @param {Boolean}
   */
  Magnet.prototype.layoutItems = function( items, instant ) {
    this._layoutItems( items, instant );
    this._postLayout();
  };

  /**
   * Update sort data
   *
   * @param {Array} elements
   */
  Magnet.prototype.updateSortData = function( elements ) {
    var items;
    // Update items data for given elements.
    // If no elements, update all items
    if ( elements ) {
      elements = utils.toArray( elements );
      items = this.getItems( elements );
    } else {
      items = this.items;
    }

    this._getSorters();
    this._updateItemsSortData( items );
  };

  /**
   * Sort items in a random order
   */
  Magnet.prototype.shuffle = function() {
    this.items.forEach( function( item ) {
      item.sortData.random = Math.random();
    });

    this.options.sortBy = 'random';
    this._sort();
    this._layout();
  };

  /**
   * Remove and disable Magnet instance and return elements to original state
   */
  Magnet.prototype.destroy = function() {
    this.items.forEach( function( item ) {
      item.destroy();
    });

    this._unbindResize();
    
    if ( jQuery ) {
      jQuery.removeData( this.element, this.constructor.namespace );
    }

    this.css({
      position: '',
      width: '',
      height: ''
    });
  };

  // -------------------- jQuery --------------------
  
  var jQuery = window.jQuery;

  /**
   * Lightweight jQuery wrapper
   * 
   * @param {String} namespace
   * @param {Function} PluginClass - plugin constructor function
   */
  function wrapper( namespace, PluginClass ) {
    // A really lightweight plugin wrapper around the constructor, 
    // preventing against multiple instantiations
    $.fn[ namespace ] = function( options ) {
      // If the first parameter is a string treat this as a call to a method
      if ( typeof options == 'string' ) {
        var args = [].slice.call( arguments, 1 );
        // Cache the method call to make it possible to return a value
        var returns;

        this.each( function() {
          var instance = $.data( this, namespace );
          if ( !instance ) {
            console.error( "Cannot call methods on '" + namespace + "' prior to initialization; attempted to call '" + options + "'" );
            return;
          }
          if ( instance instanceof PluginClass && !$.isFunction( instance[ options ] ) || options.charAt(0) === '_' ) {
            console.error( "No such method '" + options + "' for '" + namespace + "' instance" );
            return;
          }
          // Call the method of our plugin instance, and pass it the supplied arguments
          returns = instance[ options ].apply( instance, args );
        });
        // If the earlier cached method gives a value back return the value,
        // otherwise return this to preserve chainability
        return returns !== undefined ? returns : this;
      // Otherwise, instantiate a new instance of the plugin
      } else {
        return this.each( function() {
          var instance = $.data( this, namespace );
          if ( instance ) {
            instance._options( options );
            instance._init();
          } else {
            instance = new PluginClass( this, options );
            $.data( this, namespace, instance );
          }
        });
      }
    };
  }

  if ( jQuery ) {
    wrapper( 'magnet', Magnet );
  }

  // -------------------- Public APIs --------------------
  
  return Magnet;

}));