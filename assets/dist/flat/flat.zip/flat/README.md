# Flat 2.1.0

Flat is a flat-styled Bootstrap responsive navbar, presented in three different styles, that includes submenus and off canvas menu.

## Getting Started

An overview of Flat, folder structure, how to download, use it and examples.

### What's Included

Every downloaded copy of Flat is compressed. Once downloaded, unzip the compressed folder to get a structure like this:

```
flat
├── assets/
│   ├── css/
│   │   └── flat.css
│   └── js/
│       ├── flat.min.js
│       ├── html5shiv.js
│       └── respond.min.js
├── sass/
│   ├── helpers/
│   ├── mixins/
│   ├── modules/
│   └── flat.scss
├── config.rb
├── iconic.html
├── mixed.html
└── simple.html
```

- **config.rb** for sass project configuration.
- **flat.css** for style.
- **flat.min.js** for functionality.
- **html5shiv.js** to enable html5 sectioning in legacy browsers.
- **respond.min.js** to enable responsive media queries in legacy browsers.

### Installation
#### Download

For existing Bootstrap projects, copy **flat.css** and **flat.min.js** to your project, the include it in your site.

```html
<link rel="stylesheet" href="/path/to/flat.css">
<script src="/path/to/flat.min.js"></script>
```

For new projects, open **simple.html**, **mixed.html** or **iconic.html** and start typing code after `nav`.

```html
<nav class="navbar navbar-static-top navbar-default">
  ...
</nav>
<!-- Start project -->
```

## Customization
### Sass

Flat is built with Sass. To create a customized version, open `_variables.scss` file and edit variables, then compile `flat.scss` to generate a custom stylesheet.

### Colors

To change navbar color, replace `navbar-default` for `navbar-inverse`.

```html
<!-- Default color -->
<nav class="navbar navbar-default">
  ...
</nav>
<!-- Inverse color -->
<nav class="navbar navbar-inverse">
  ...
</nav>
```

### Display

To change navbar to an off canvas menu, add `navbar-offcanvas` and `navbar-fixed-left` or `navbar-fixed-right` to place the menu on the selected side.

```html
<!-- Off canvas -->
<nav class="navbar navbar-offcanvas navbar-fixed-left">
  ...
</nav>
```

### Position

To change navbar position, replace `navbar-static-top` for `navbar-fixed-top` or `navbar-fixed-bottom`.

```html
<!-- Scrolls away with the page -->
<nav class="navbar navbar-static-top">
  ...
</nav>
<!-- Fixed to top, overlays page content -->
<nav class="navbar navbar-fixed-top">
  ...
</nav>
<!-- Fixed to bottom, overlays page content -->
<nav class="navbar navbar-fixed-bottom">
  ...
</nav>
```

To change off canvas menu position, replace `navbar-static-top` for `navbar-fixed-left` or `navbar-fixed-right`.

```html
<!-- Off canvas, fixed to left -->
<nav class="navbar navbar-offcanvas navbar-fixed-left">
  ...
</nav>
<!-- Off canvas, fixed to right -->
<nav class="navbar navbar-offcanvas navbar-fixed-left">
  ...
</nav>
```

Fixed positions requires body padding.

### Icons

Flat uses [FontAwesome](http://fontawesome.io/) icons. You can replace this icons for Glyphicons, included in Bootstrap.

```html
<!-- FontAwesome -->
<span class="fa fa-icon"></span>
<!-- Glyphicon -->
<span class="glyphicon glyphicon-icon"></span>
```

### Compatibility

Bootstrap presents some related issues on Internet Explorer 9 and previous versions. In case you must support this browsers, CDN served Bootstrap has to be replaced for a downloaded copy. Also, include **htmlshiv.js** and **respond.min.js** in your project.

```html
<!-- Required files for IE<=9 -->
<link rel="stylesheet" href="/path/to/bootstrap.min.css">
<script src="/path/to/bootstrap.min.js"></script>
<script src="/path/to/html5shiv.js"></script>
<script src="/path/to/respond.min.js"></script>
```

For more information about Bootstrap browser compatibility, visit [browser and device support](http://getbootstrap.com/getting-started/#support).

[TOC]